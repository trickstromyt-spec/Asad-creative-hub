// auth.js
document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    const loginForm = document.getElementById('loginForm');
    const authError = document.getElementById('authError');
    const adminEmail = 'asadarisar21@gmail.com';

    // Helper to show errors
    const showError = (message) => {
        if(authError) {
            authError.textContent = message;
            authError.style.display = 'block';
        }
    };

    // Signup Logic
    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const submitBtn = document.getElementById('signupBtn');
            const originalBtnHtml = submitBtn.innerHTML;

            submitBtn.innerHTML = '<span>Signing up...</span><i class="fas fa-spinner fa-spin"></i>';
            submitBtn.disabled = true;
            authError.style.display = 'none';

            try {
                const { data, error } = await supabaseClient.auth.signUp({
                    email,
                    password,
                    options: {
                        data: {
                            full_name: name
                        }
                    }
                });

                if (error) throw error;

                // Signup successful
                submitBtn.innerHTML = '<span>Success! Redirecting...</span><i class="fas fa-check"></i>';
                submitBtn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
                
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);

            } catch (error) {
                console.error("Signup error:", error);
                showError(error.message || 'An error occurred during sign up.');
                submitBtn.innerHTML = originalBtnHtml;
                submitBtn.disabled = false;
            }
        });
    }

    // Login Logic
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const submitBtn = document.getElementById('loginBtn');
            const originalBtnHtml = submitBtn.innerHTML;

            submitBtn.innerHTML = '<span>Logging in...</span><i class="fas fa-spinner fa-spin"></i>';
            submitBtn.disabled = true;
            authError.style.display = 'none';

            try {
                const { data, error } = await supabaseClient.auth.signInWithPassword({
                    email,
                    password
                });

                if (error) throw error;

                // Login successful
                submitBtn.innerHTML = '<span>Success! Redirecting...</span><i class="fas fa-check"></i>';
                submitBtn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
                
                setTimeout(() => {
                    // Route admins to admin dashboard, regular users to home
                    if (data.user && data.user.email === adminEmail) {
                        window.location.href = 'admin.html';
                    } else {
                        window.location.href = 'index.html';
                    }
                }, 1000);

            } catch (error) {
                console.error("Login error:", error);
                showError(error.message || 'Invalid login credentials.');
                submitBtn.innerHTML = originalBtnHtml;
                submitBtn.disabled = false;
            }
        });
    }
});
