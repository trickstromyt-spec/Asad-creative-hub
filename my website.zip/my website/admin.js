// admin.js
document.addEventListener('DOMContentLoaded', async () => {
    const adminEmail = 'asadarisar21@gmail.com';

    // 1. Check Authentication
    const { data: { session } } = await supabaseClient.auth.getSession();
    
    if (!session || session.user.email !== adminEmail) {
        // Not admin, redirect
        window.location.href = 'login.html';
        return;
    }

    // Is Auth'd Admin
    document.body.style.display = 'block';
    
    // Set Date
    const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-US', dateOptions);
    
    // 2. Tab Navigation
    const links = document.querySelectorAll('.sidebar-link');
    const panes = document.querySelectorAll('.tab-pane');
    const pageTitle = document.getElementById('pageTitle');

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove active
            links.forEach(l => l.classList.remove('active'));
            panes.forEach(p => p.classList.remove('active'));
            
            // Add active
            link.classList.add('active');
            const targetId = link.getAttribute('data-tab');
            document.getElementById('tab-' + targetId).classList.add('active');
            
            // Update Title
            pageTitle.textContent = link.textContent.trim();
        });
    });

    // 3. Logout
    document.getElementById('logoutBtn').addEventListener('click', async () => {
        await supabaseClient.auth.signOut();
        window.location.href = 'login.html';
    });

    // 4. Fetch Data
    fetchMessages();
    fetchUsers();

    // Fetch Messages
    async function fetchMessages() {
        // Fetch from 'messages' table, order by created_at desc
        const { data, error, count } = await supabaseClient
            .from('messages')
            .select('*', { count: 'exact' })
            .order('created_at', { ascending: false });

        if (error) {
            console.error("Error fetching messages:", error);
            document.getElementById('totalMessagesStat').textContent = "Error";
            return;
        }

        document.getElementById('totalMessagesStat').textContent = count || data.length;

        const allBody = document.getElementById('allMessagesBody');
        const recentBody = document.getElementById('recentMessagesBody');
        
        allBody.innerHTML = '';
        recentBody.innerHTML = '';

        if (data.length === 0) {
            allBody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 32px;">No messages found.</td></tr>`;
            recentBody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 32px;">No messages found.</td></tr>`;
            return;
        }

        data.forEach((msg, index) => {
            const date = new Date(msg.created_at || new Date()).toLocaleDateString();
            
            // For All Messages
            const trAll = document.createElement('tr');
            trAll.innerHTML = `
                <td class="text-primary">${msg.name || 'Anonymous'}</td>
                <td><a href="mailto:${msg.email}" style="color: inherit; text-decoration: underline;">${msg.email}</a></td>
                <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${msg.project_details || ''}">
                    ${msg.project_details || '-'}
                </td>
                <td class="text-muted">${date}</td>
                <td>
                    <button class="btn-delete" onclick="deleteMessage('${msg.id}')">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            allBody.appendChild(trAll);

            // For Recent Dashboard (Limit to 5)
            if (index < 5) {
                const trRecent = document.createElement('tr');
                trRecent.innerHTML = `
                    <td class="text-primary">${msg.name || 'Anonymous'}</td>
                    <td>${msg.email}</td>
                    <td class="text-muted">${date}</td>
                    <td>
                        <button class="btn-delete" onclick="deleteMessage('${msg.id}')">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </td>
                `;
                recentBody.appendChild(trRecent);
            }
        });
    }

    // Delete Message function (Global)
    window.deleteMessage = async function(id) {
        if(confirm('Are you sure you want to delete this message?')) {
            const { error } = await supabaseClient
                .from('messages')
                .delete()
                .eq('id', id);
            
            if (error) {
                alert("Error deleting message: " + error.message);
                return;
            }
            
            // Refresh
            fetchMessages();
        }
    };

    // Fetch Users
    async function fetchUsers() {
        // Note: Unless a dedicated Profiles table is public or a function exists, 
        // ordinary client can't query auth.users out of the box due to security.
        // As a workaround since this is for a tutorial/demo, we'll try querying auth schema if permissions allow,
        // or just mock it / show the current admin user if no users table is setup.
        
        // Let's attempt to use Supabase rpc to get users if the user sets it up, 
        // or gracefully degrade to showing just a placeholder.
        
        // To be practical for this frontend-only implementation, we will display an informational note 
        // if 'auth.users' cannot be queried directly from client side.
        
        const tbody = document.getElementById('allUsersBody');
        tbody.innerHTML = `
            <tr>
                <td class="text-primary">${adminEmail}</td>
                <td class="text-muted">Admin Since Genesis</td>
                <td><span class="badge badge-success">Admin</span></td>
            </tr>
            <tr>
                <td colspan="3" class="text-muted" style="text-align: center; padding: 20px;">
                    <em>Note: Reading all registered users from Supabase requires a backend or a public profiles table setup due to security rules on the auth.users table. Only the admin is listed currently.</em>
                </td>
            </tr>
        `;
        document.getElementById('totalUsersStat').textContent = "1+";
    }

});
