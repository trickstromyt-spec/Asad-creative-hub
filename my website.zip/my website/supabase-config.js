// Supabase Configuration
// Requires the Supabase JS SDK to be loaded before this file.

const supabaseUrl = 'https://vcfhdhgjenezsoznbcmz.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZjZmhkaGdqZW5lenNvem5iY216Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMDE1NDgsImV4cCI6MjA4ODg3NzU0OH0.R4jBW50UaD5Ikk-Bha1rRjeRmU-LWefGBwUkQhcRB4U';

window.supabaseClient = window.supabase.createClient(supabaseUrl, supabaseKey);
